﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.IO;

namespace knapsack
{
    public partial class Form1 : Form
    {
        public struct thing
        {
            public int weight;
            public int cost;

            public thing(int weight, int cost)
            {
                this.weight = weight;
                this.cost = cost;
            }
        }

        public List<thing> thing_list = new List<thing>();
        public int[,] array;
        public int weight_knapsack;
        public List<int> answer;
        public bool flag_automatic = false;
        public int flag_step = 0;
        public bool flag_program_execution = true;
        public int timer = 300;

        public Form1()
        {
            InitializeComponent();
        }

        public void ReadCountData()
        {
            weight_knapsack = Convert.ToInt32(textBox_weight_knapsack.Text);
            int count_thing = Convert.ToInt32(textBox_count_thing.Text);
            dataGridView1.ColumnCount = count_thing;
            dataGridView1.RowCount = 2;
            dataGridView1.Rows[0].HeaderCell.Value = "Вес";
            dataGridView1.Rows[1].HeaderCell.Value = "Стоимость";

            for (int i = 1; i <= count_thing; i++)
            {
                dataGridView1.Columns[i - 1].HeaderText = (i).ToString();
            }
        }

        public void ReadList()
        {
            thing_list = new List<thing>();
            for (int i = 0; i < dataGridView1.Columns.Count; i++)
            {
                thing_list.Add(new thing(Convert.ToInt32(dataGridView1[i, 0].Value), Convert.ToInt32(dataGridView1[i, 1].Value)));
            }
        }

        public void CreateArray()
        {
            array = new int[thing_list.Count + 1, weight_knapsack + 1];
            for (int i = 0; i <= thing_list.Count; i++)
            {
                for (int j = 0; j <= weight_knapsack; j++)
                {
                    array[i, j] = 0;
                }
            }
        }

        public int Max(int a, int b)
        {
            if (a > b)
            {
                return a;
            }
            return b;
        }

        public void MainProgram()
        {
            for (int i = 1; i <= thing_list.Count; i++)
            {
                flag_program_execution = false;
                dataGridView1[i - 1, 1].Style.BackColor = System.Drawing.Color.Yellow;
                dataGridView1[i - 1, 0].Style.BackColor = System.Drawing.Color.Yellow;
                Thread.Sleep(2 * timer);
                for (int j = 1; j <= weight_knapsack; j++)
                {
                    dataGridView4[1, 0].Value = "";
                    dataGridView4[1, 1].Value = "";
                    dataGridView4[1, 2].Value = "";
                    dataGridView2[j - 1, i].Style.BackColor = System.Drawing.Color.Yellow;
                    Thread.Sleep(timer);
                    while (!flag_automatic && flag_step == 0)
                    {
                        Thread.Sleep(100);
                    }
                    int t = 0;
                    if (flag_step == -1)
                    {
                        dataGridView2[j - 1, i].Style.BackColor = System.Drawing.Color.White;
                        if (j != 1)
                        {
                            j = j - 2;
                        }
                        else
                        {
                            dataGridView1[i - 1, 1].Style.BackColor = System.Drawing.Color.White;
                            dataGridView1[i - 1, 0].Style.BackColor = System.Drawing.Color.White;
                            i = i - 1;
                            j = weight_knapsack - 1;
                            if (i - 1 < 0) {
                                flag_program_execution = true;
                                flag_step = 0;
                                flag_automatic = false;
                                return;
                            }
                            dataGridView1[i - 1, 1].Style.BackColor = System.Drawing.Color.Yellow;
                            dataGridView1[i - 1, 0].Style.BackColor = System.Drawing.Color.Yellow;
                        }
                        dataGridView2[j, i].Value = 0;
                        dataGridView2[j, i].Style.BackColor = System.Drawing.Color.White;
                        Thread.Sleep(timer);
                    }
                    else
                    {
                        if (thing_list[i - 1].weight <= j)
                        {
                            System.Drawing.Color backColor1 = dataGridView2[j - 1, i - 1].Style.BackColor;
                            dataGridView2[j - 1, i - 1].Style.BackColor = System.Drawing.Color.Blue;
                            System.Drawing.Color backColor2 = System.Drawing.Color.Green;
                            if (j - thing_list[i - 1].weight - 1 >= 0)
                            {
                                backColor2 = dataGridView2[j - thing_list[i - 1].weight - 1, i - 1].Style.BackColor;
                                dataGridView2[j - thing_list[i - 1].weight - 1, i - 1].Style.BackColor = System.Drawing.Color.Blue;
                            }
                            dataGridView4[0, 0].Value = "Берем предмет";
                            dataGridView4[0, 1].Value = "Не берем предмет";
                            dataGridView4[0, 2].Value = "Максимум";
                            dataGridView4[1, 0].Value = array[i - 1, j - thing_list[i - 1].weight] + thing_list[i - 1].cost;
                            dataGridView4[1, 1].Value = array[i - 1, j];
                            dataGridView4[1, 2].Value = Max(array[i - 1, j],
                                array[i - 1, j - thing_list[i - 1].weight] + thing_list[i - 1].cost);
                            array[i, j] = Max(array[i - 1, j],
                                array[i - 1, j - thing_list[i - 1].weight] + thing_list[i - 1].cost);
                            Thread.Sleep(timer * 2);
                            if (flag_step != 0)
                            {
                                flag_step = 0;
                                while (flag_step == 0 && !flag_automatic)
                                {
                                    Thread.Sleep(100);
                                }
                                t = flag_step;
                            }
                            dataGridView2[j - 1, i].Style.BackColor = System.Drawing.Color.Green;
                            dataGridView2[j - 1, i - 1].Style.BackColor = backColor1;
                            if (j - thing_list[i - 1].weight - 1 >= 0)
                            {
                                dataGridView2[j - thing_list[i - 1].weight - 1, i - 1].Style.BackColor = backColor2;
                            }
                            dataGridView2[j - 1, i].Value = array[i, j];
                            Thread.Sleep(timer * 2);
                        }
                        else
                        {
                            array[i, j] = array[i - 1, j];
                            dataGridView2[j - 1, i].Style.BackColor = System.Drawing.Color.Red;
                            dataGridView2[j - 1, i].Value = array[i, j];
                            Thread.Sleep(timer);
                        }
                    }
                    flag_step = t;
                }
                dataGridView1[i - 1, 1].Style.BackColor = System.Drawing.Color.White;
                dataGridView1[i - 1, 0].Style.BackColor = System.Drawing.Color.White;
            }
            timer = 300;
            print_things(thing_list.Count, weight_knapsack);
            for (int i = 0; i < 30; i++)
            {
                dataGridView4[0, i].Value = " ";
                dataGridView4[1, i].Value = " ";
            }
            for (int i = 0; i < answer.Count; i++)
            {
                dataGridView4[0, i].Value = answer[i] + 1;
            }
            flag_program_execution = true;
            flag_step = 0;
            flag_automatic = false;
        }

        public void WriteArray()
        {
            dataGridView2.ColumnCount = weight_knapsack;
            dataGridView2.RowCount = thing_list.Count + 1;
            for (int i = 0; i < weight_knapsack; i++)
            {
                dataGridView2.Columns[i].HeaderText = (i + 1).ToString();
                dataGridView2.Columns[i].Width =  700 / (weight_knapsack + 1);
                if (weight_knapsack > 50)
                {
                    dataGridView2.Columns[i].Width = 40;
                }
            }
            for (int i = 0; i <= thing_list.Count; i++)
            {
                dataGridView2.Rows[i].HeaderCell.Value = i.ToString();
            }
            for (int i = 0; i <= thing_list.Count; i++)
            {
                for (int j = 1; j <= weight_knapsack; j++)
                {
                    dataGridView2[j - 1, i].Value = 0;
                }
            }
            dataGridView4.ColumnCount = 10;
            dataGridView4.RowCount = 30;
            dataGridView4.Columns[0].Width = 150;
        }
            
        public void print_things(int n, int w) {
            if (array[n, w] == 0)
            {
                return;
            }
            if (array[n - 1, w] == array[n, w])
            {                
                if (w - 1 >= 0 && n >= 0)
                {
                    dataGridView2[w - 1, n].Style.BackColor = System.Drawing.Color.AntiqueWhite;
                    Thread.Sleep(timer);
                }
                print_things(n - 1, w);

            }
            else
            {
                if (w - 1 >= 0 && n >= 0)
                {
                    dataGridView2[w - 1, n].Style.BackColor = System.Drawing.Color.Yellow;
                }
                Thread.Sleep(timer);
                print_things(n - 1, w - thing_list[n - 1].weight);
                answer.Add(n - 1);
            }
        }

        public void WriteAnswerThread()
        {
            timer = 300;
            print_things(thing_list.Count, weight_knapsack);
            for (int i = 0; i < answer.Count; i++)
            {
                // dataGridView3[i, 0].Value = answer[i] + 1;
            }
        }

        public void WriteAnswer()
        {
            answer = new List<int>();
            for (int i = 0; i < 30; i++)
            {
                dataGridView4[0, i].Value = " ";
                dataGridView4[1, i].Value = " ";
            }
        }

        public void ClearDataGridView()
        {
            for (int i = 1; i <= thing_list.Count; i++)
            {
                for (int j = 1; j <= weight_knapsack; j++)
                {
                    dataGridView2[j - 1, i].Style.BackColor = System.Drawing.Color.White;
                }
            }
            dataGridView2.BackColor = System.Drawing.Color.White;
            dataGridView2.Refresh();
        }

        public void InputExample(int count_thing)
        {
            dataGridView1.ColumnCount = count_thing;
            dataGridView1.RowCount = 2;
            dataGridView1.Rows[0].HeaderCell.Value = "Вес";
            dataGridView1.Rows[1].HeaderCell.Value = "Стоимость";

            for (int i = 0; i < count_thing; i++)
            {
                dataGridView1.Columns[i].HeaderText = (i + 1).ToString();
                dataGridView1[i, 0].Value = thing_list[i].weight;
                dataGridView1[i, 1].Value = thing_list[i].cost;
            }
            textBox_count_thing.Text = count_thing.ToString();
            textBox_weight_knapsack.Text = weight_knapsack.ToString();
        }

        public void MainAction()
        {
            CreateArray();
            WriteArray();
            ClearDataGridView();
            WriteAnswer();
            Thread myThread = new Thread(new ThreadStart(MainProgram));
            myThread.Start();
            Thread.Sleep(300);
        }

        private void button_input_weight_count_Click(object sender, EventArgs e)
        {
            if (flag_program_execution)
            {
                ReadCountData();
            }
            else
            {
                MessageBox.Show("Дождитесь окончания выполнения программы");
            }
            
        }

        private void button_input_things_Click(object sender, EventArgs e)
        {
            if (flag_program_execution)
            {
                ReadList();
                MainAction();
            }
            else
            {
                MessageBox.Show("Дождитесь окончания выполнения программы");
            }
        }

        private void button_automatic_Click(object sender, EventArgs e)
        {
            if (!flag_program_execution)
            {
                flag_automatic = !flag_automatic;
                timer = 300;
            }
        }

        private void button_next_Click(object sender, EventArgs e)
        {
            if (!flag_program_execution)
            {
                flag_step = 1;
            }
        }

        private void button_prev_Click(object sender, EventArgs e)
        {
            if (!flag_program_execution)
            {
                flag_step = -1;
            }
        }

        private void button_timer_plus_Click(object sender, EventArgs e)
        {
            if (timer > 0)
            {
                timer = timer - 100;
            }
        }

        private void button_timer_minus_Click(object sender, EventArgs e)
        {
            timer = timer + 100;
        }

        private void exp1_Click(object sender, EventArgs e)
        {
            if (flag_program_execution)
            {
                weight_knapsack = 13;
                int count_thing = 5;
                thing_list = new List<thing>();
                thing_list.Add(new thing(3, 1));
                thing_list.Add(new thing(4, 6));
                thing_list.Add(new thing(5, 4));
                thing_list.Add(new thing(8, 7));
                thing_list.Add(new thing(9, 6));
                InputExample(count_thing);
                MainAction();
            }
            else
            {
                MessageBox.Show("Дождитесь окончания выполнения программы");
            }
        }

        private void exp2_Click(object sender, EventArgs e)
        {
            if (flag_program_execution)
            {
                string path = @"ex1.txt";
                int count_thing;
                thing_list = new List<thing>();
                using (StreamReader sr = new StreamReader(path, System.Text.Encoding.Default))
                {
                    string line;
                    line = sr.ReadLine();
                    string[] words = line.Split(' ');
                    weight_knapsack = Convert.ToInt32(words[1]);
                    count_thing = Convert.ToInt32(words[0]);
                    line = sr.ReadLine();
                    string[] w1 = line.Split(' ');
                    line = sr.ReadLine();
                    string[] s1 = line.Split(' ');
                    for (int i = 0; i < count_thing; i++)
                    {
                        thing_list.Add(new thing(Convert.ToInt32(w1[i]), Convert.ToInt32(s1[i])));
                    }
                }
            /*    string writePath = @"ex1.txt";
                Random rnd = new Random();
                int value = rnd.Next(1, 200);
                string text = value.ToString();
                int value1 = rnd.Next(0, 200);
                string text1 = value.ToString();
                for (int i = 1; i < 200; i++)
                {
                    value = rnd.Next(0, 200);
                    text = text + " " + value.ToString();
                    value1 = rnd.Next(0, 200);
                    text1 = text1 + " " + value1.ToString();
                }
            //    MessageBox.Show(text);
                using (StreamWriter sw = new StreamWriter(writePath, false, System.Text.Encoding.Default))
                {
                    sw.WriteLine(text);
                    sw.WriteLine(text1);
                }*/
                InputExample(count_thing);
                MainAction();
            }
            else
            {
                MessageBox.Show("Дождитесь окончания выполнения программы");
            }
        }

        private void exp3_Click(object sender, EventArgs e)
        {
            if (flag_program_execution)
            {
                weight_knapsack = 10;
                int count_thing = 10;
                thing_list = new List<thing>();
                thing_list.Add(new thing(1, 6));
                thing_list.Add(new thing(2, 3));
                thing_list.Add(new thing(10, 8));
                thing_list.Add(new thing(6, 1));
                thing_list.Add(new thing(5, 7));
                thing_list.Add(new thing(1, 3));
                thing_list.Add(new thing(7, 8));
                thing_list.Add(new thing(4, 6));
                thing_list.Add(new thing(10, 5));
                thing_list.Add(new thing(4, 6));
                InputExample(count_thing);
                MainAction();
            }
            else
            {
                MessageBox.Show("Дождитесь окончания выполнения программы");
            }
        }
    }
}
